﻿using EntityClassesLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using System.Data;

namespace DAL
{
    public class CustomerDBRepo : IDataAccess
    {
        private SqlConnection conn;
        private SqlCommand comm;
        private SqlDataReader reader;
        List<Customer> allcustomers = new List<Customer>();
        List<Account> allaccounts = new List<Account>();
        public CustomerDBRepo()
        {
            this.conn = new SqlConnection("server=CTAADPG038PAB\\SQLEXPRESS;database=cessnadb;uid=sa;pwd=Password_123;TrustServerCertificate=true;");
            conn.Open();
            Console.WriteLine("DAL Connected to SQL Server");
        }
        public void AddNewCustomer(Customer c)
        {
          
            //string sql = "insert into customers values(@cid,@cname,@city, @state, @email)";
            //comm = new SqlCommand(sql);
            comm = new SqlCommand();
            comm.Connection = conn;

            // to call a proc
            comm.CommandType = CommandType.StoredProcedure;
            comm.CommandText = "InsertCustomer";

            //tell the Sql Command about the parameters
            comm.Parameters.AddWithValue("@cid", c.CustomerId);
            comm.Parameters.AddWithValue("@cname", c.CustomerName);
            comm.Parameters.AddWithValue("@customercity", c.Address.City);
            comm.Parameters.AddWithValue("@customerstate", c.Address.State);
            comm.Parameters.AddWithValue("@email", "karthik@yahoo.com");

            int recordsinserted = comm.ExecuteNonQuery();
            Console.WriteLine("{0}records inserted", recordsinserted);

        }

        public void DeleteCustomer(int customerid)
        {
            //throw new NotImplementedException();
        }

        public void EditCustomer(int customerid, Customer c)
        {
            //throw new NotImplementedException();
        }

        public void CreateAccount(Account a)
        {
            comm = new SqlCommand();
            comm.Connection = conn;

            // to call a proc
            comm.CommandType = CommandType.StoredProcedure;
            comm.CommandText = "InsertAccount";
            //tell the Sql Command about the parameters
            comm.Parameters.AddWithValue("@accid", a.AccountId);
            comm.Parameters.AddWithValue("@acctype", a.AccType);
            comm.Parameters.AddWithValue("@balance", a.Balance);
            comm.Parameters.AddWithValue("@cid", a.CustomerId);

            int recordsinserted = comm.ExecuteNonQuery();
            Console.WriteLine("{0}records inserted", recordsinserted);
            if (recordsinserted > 0)
            {
                Console.WriteLine("Account Created Successfully");
            }
            else Console.WriteLine("Some error occured while creating the account");

            return;
        }

        public List<Customer> GetAllCustomers()
        {
            string sql = "select * from customers";
            comm = new SqlCommand(sql);
            comm.Connection = conn;     //associate command with connection

            reader = comm.ExecuteReader();
            if (reader.HasRows == false)
            {
                Console.WriteLine("No customers to show");
            }
            else
            {
                while (reader.Read())
                {
                    //read each now one by one and get the columns
                    Customer c = new Customer();
                    c.CustomerId = (int)reader["customerid"];
                    c.CustomerName = reader["customername"].ToString();
                    CustomerAddress ca = new CustomerAddress();
                    ca.City = reader["city"].ToString();
                    ca.State = reader["state"].ToString();
                    c.Address = ca;
                    allcustomers.Add(c);
                }
            }
            reader.Close();



            return allcustomers;
        }

        private static bool flag = true;
        private static List<Account> accounts = null;
        public List<Account> GetAccountsForCustomer(int cid)
        {

            if (flag)
            {
                //List<Account> accounts = new List<Account>();
                string sql = "select * from account where CustomerId=customerid";
                comm = new SqlCommand(sql);
                comm.Connection = conn;     //associate command with connection

                comm.Parameters.AddWithValue("@cid", cid);

                reader = comm.ExecuteReader();
                if (reader.HasRows == false)
                {
                    Console.WriteLine("No accounts to show");
                }
                else
                {
                    while (reader.Read())
                    {

                        Console.WriteLine("Account Number: " + reader["AccountId"]);
                        Console.WriteLine("Account Type: " + reader["AccountType"]);
                        Console.WriteLine("Balance: " + reader["Balance"]);
                        Console.WriteLine("------------------------------");
                        Console.ReadKey();

                        //    read each now one by one and get the columns
                        //    Account a = new Account();
                        //    a.CustomerId = (int)reader["customerid"];
                        //    a.AccType = (AccountType)reader.GetInt32(1);
                        //    a.Balance = reader.GetInt32(2);
                        //    a.AccountId= (int)reader["accid"];
                        //    a.AccountId = reader.GetInt32(3);

                        //    allaccounts.Add(a);
                        //}

                    } 
    
            }  reader.Close();

         }


            return allaccounts;
        }
        public List<Account> GetAccounts(AccountType acctype)
        {
            List<Account> accounts = new List<Account>();
            string sql = "select * from account where AccountType=@Type";
            comm = new SqlCommand(sql);
            comm.Connection = conn;     //associate command with connection
            comm.Parameters.AddWithValue("@Type", (int)acctype);


            reader = comm.ExecuteReader();
            if (reader.HasRows == false)
            {
                Console.WriteLine("No accounts to show");
            }
            else
            {
                while (reader.Read())
                {

                    Console.WriteLine("");
                    Console.WriteLine("");
                    Account account = new Account();
                    Console.WriteLine("Account Number: " + reader["AccountId"]);
                    Console.WriteLine("Customer Number: " + reader["CustomerId"]);
                    Console.WriteLine("------------------------------");

                    //Account account = new Account();
                    //account.AccountId = reader.GetInt32(0);
                    //account.AccType = (AccountType)reader.GetInt32(1);
                    //account.Balance = reader.GetInt32(2);
                    //account.CustomerId = reader.GetInt32(3);

                }

            }

            reader.Close();

            return allaccounts;
        }

        public double Transaction(string transaction, int accid, double amt)
        {

            double currentBalance = 0;

            if (transaction.ToLower() == "deposit")
            {

                // Create and execute the UPDATE query
                string sql = "UPDATE account SET balance = balance + @amt WHERE AccountId = @accid";
                comm = new SqlCommand(sql);
                comm.Connection = conn;

                comm.Parameters.AddWithValue("@amt", amt);
                comm.Parameters.AddWithValue("@accid", accid);
                comm.ExecuteNonQuery();

            }
            else if (transaction.ToLower() == "withdraw")
            {
                // Create and execute the UPDATE query
                string sql = "UPDATE account SET balance = balance - @amt WHERE AccountId = @accid";
                comm = new SqlCommand(sql);
                comm.Connection = conn;

                comm.Parameters.AddWithValue("@amt", amt);
                comm.Parameters.AddWithValue("@accid", accid);
                comm.ExecuteNonQuery();

            }
            else
            {
                // Throw an exception if the transaction type is invalid
                throw new Exception("Invalid transaction type: " + transaction);
            }

            // Get the current balance
            string balanceQuery = "SELECT balance FROM account WHERE AccountId = @accid";
            comm = new SqlCommand(balanceQuery);
            comm.Connection = conn;

            comm.Parameters.AddWithValue("@amt", amt);
            comm.Parameters.AddWithValue("@accid", accid);
            currentBalance = (int)comm.ExecuteNonQuery();
            comm.Connection = conn;
            comm.ExecuteNonQuery();

            reader = comm.ExecuteReader();
            if (reader.HasRows == false)
            {
                Console.WriteLine("No accounts to update");
            }
            else
            {
                while (reader.Read())
                {
                    Account a = new Account();

                    allaccounts.Add(a);
                }
            }
            reader.Close();

            return currentBalance;

            //return;
        }
        public void PersistData()
        {
            //throw new NotImplementedException();
        }

        public void ReadData()
        {
            //throw new NotImplementedException();
        }

        public void Dispose()
        {
            if (this.conn != null)
            {
                conn.Close();
                Console.WriteLine("SQL Connection Closed");
            }
        }



    }
}
