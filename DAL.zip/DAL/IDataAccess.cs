using EntityClassesLib;
namespace DAL
{
    public interface IDataAccess
    {
        List<Customer> GetAllCustomers();
        void AddNewCustomer(Customer c);
        void EditCustomer(int customerid, Customer c);
        void DeleteCustomer(int customerid);


        void CreateAccount(Account a);
        List<Account> GetAccountsForCustomer(int cid);
        List<Account> GetAccounts(AccountType acctype);

        double Transaction(string transaction, int accid, double amt);

        void PersistData();
        void ReadData();
    }
}