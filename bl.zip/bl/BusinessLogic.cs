﻿using System.Security.Cryptography;
using System.Text;
using EntityClassesLib;
using LoggerLib;
using BankService = BankServiceLayer.BankServiceLayer;

namespace bl
{

    public class BusinessLogic
    {
        private BankService bsl = new BankService();

        private FileLogger filelogger;
        public List<RevisedCustomer> ObtainAllCustomerList()
        {
            using (filelogger = new FileLogger())
            {
                this.filelogger.Log("ObtainAllCustomers() called at:" + DateTime.Now);
            }
           

            List<Customer> customers = bsl.HttpGetAllCustomers();
            List<RevisedCustomer> result = new List<RevisedCustomer>();
            foreach (Customer cm in customers)
            {
                RevisedCustomer rc = new RevisedCustomer();
                rc.CID = cm.CustomerId;
                rc.CName = cm.CustomerName.ToUpper();
                rc.Address = cm.Address.City + " " + cm.Address.State;
                result.Add(rc);
            }
            return result;

        }
        //-----


        //------
        public void InsertCustomer(int cid, string cname, string city, string state)

        {
            using (filelogger = new FileLogger())
            {
                this.filelogger.Log("InsertCustomer() called at:" + DateTime.Now);
            }
            //this.filelogger.Log("InsertCustomer() called at:" +DateTime.Now);
            //        this.filelogger.Dispose();
            Customer c = new Customer();

            c.CustomerId = cid;

            c.CustomerName = cname;

            CustomerAddress ca = new CustomerAddress();

            ca.City = city;

            ca.State = state;

            c.Address = ca;

            bsl.HttpPostCustomer(c);

        }

        public void ModifyCustomer(int cid, string newname, string newcity, string newstate)
        {
            using (filelogger = new FileLogger())
            {
                this.filelogger.Log("ModifyCustomer() called at:" + DateTime.Now);
            }
            //this.filelogger.Log("ModifyCustomer() called at:" +DateTime.Now);
            //        this.filelogger.Dispose();

            Customer c = new Customer();
            c.CustomerId = cid;
            c.CustomerName = newname;
            CustomerAddress ca = new CustomerAddress();

            ca.City = newcity;
            ca.State = newstate;
            c.Address = ca;

            bsl.PutCustomer(cid, c);
        }

        public void RemoveCustomer(int cid)
        {
            using (filelogger = new FileLogger())
            {
                this.filelogger.Log("RemoveCustomer() called at:" + DateTime.Now);
            }

            //t/*his.filelogger.Dispose();*/
            Customer c = new Customer();
            c.CustomerId = cid;

            bsl.DeleteCustomer(cid);
        }

        public void CreateAccount(int accid, AccountType acctype, int balance, int customerid)
        {
            using (filelogger = new FileLogger())
            {
                this.filelogger.Log("CreateAccount() called at:" + DateTime.Now);
            }

            Account a = new Account();
            a.AccountId = accid;
            a.AccType = acctype;
            a.Balance = balance;
            a.CustomerId = customerid;

            bsl.NewAccount(a);
        }

        public void GetAccountsForCustomer(int cid)
        {
            using (filelogger = new FileLogger())
            {
                this.filelogger.Log("GetAccountsForCustomer() called at:" + DateTime.Now);
            }
            List<Account> accounts = bsl.GetAccountsForCustomer(cid);
            foreach (Account account in accounts)
            {
                Account acct = new Account();
                acct.AccountId = cid;

            }
            bsl.GetAccountsForCustomer(cid);
        }

        public void GetAccounts(AccountType acctype)
        {
            using (filelogger = new FileLogger())
            {
                this.filelogger.Log("GetAccounts for account type called at:" + DateTime.Now);
            }
            List<Account> accounts = bsl.GetAccounts(acctype);
            foreach (Account account in accounts)
            {
                Account acct = new Account();
                acct.AccType = acctype;
            }

            bsl.GetAccounts(acctype);
        }

        public double Transaction(string transaction, int accid, double amt)
        {
            using (filelogger = new FileLogger())
            {
                this.filelogger.Log("Transaction() called at:" + DateTime.Now);
            }

            return bsl.Transaction(transaction, accid, amt);
        }

        /// <summary>
        /// 
        /// </summary>

        public void PersistData()
        {
            this.bsl.PersistData();
        }
        public void ReadData()
        {
            this.bsl.ReadData();
        }

    }
    public class RevisedCustomer
    {
        public int CID { get; set; }
        public string CName { get; set; }
        public string Address { get; set; }

        public override string ToString()
        {
            // string details=this.CID.ToString();
            // details +="," +this.CName;
            // details +="," +this.Address;
            // return details;

            //use string builder

            StringBuilder sb = new StringBuilder();
            sb.Append("Customer Id:" + this.CID);

            sb.Append("\nCustomer Name:" + this.CName);

            sb.Append("\nCustomer City & State:" + this.Address);

            return sb.ToString();


        }



    }

    //public class RevisedAccount
    //{
    //    public int AccID { get; set; }

    //    public string CID { get; set; }

    //    public override string ToString()
    //    {
    //        //    string details = this.CID.ToString();
    //        //    details += "," + this.AccID;

    //        //return details;

    //       // use string builder

    //        StringBuilder sb = new StringBuilder();
    //        sb.Append("Account Id:" + this.AccID);

    //        sb.Append("\nCustomer Id" + this.CID);

    //        return sb.ToString();


    //    }



}






